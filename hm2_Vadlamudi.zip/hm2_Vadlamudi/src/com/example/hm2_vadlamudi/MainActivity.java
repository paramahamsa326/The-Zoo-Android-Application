package com.example.hm2_vadlamudi;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
/*
 * Author	 : Parama Hamsa Vadlamdui
 * LID		 : L20373468
 * Assignment: 2
 * Subject	 : COSC 4301/5340 Android Programming
 * Objective : Creating an android application, which displays animals based on pressing two buttons
 */
public class MainActivity extends Activity implements OnClickListener {

	public static final String DEBUG_LOG="ProjectLogging"; 
	//Declaration of elements appear on the screen
	ImageView imageView1;
	Button button1, button2;
	int imageIndex=0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//finding and setting view and activity of elements on the screen
		Log.i (DEBUG_LOG, "Creating Activity");
		imageView1 = (ImageView) findViewById (R.id.imageView1);
		button1 =(Button)findViewById ( R.id.button1);
		button2 =(Button)findViewById ( R.id.button2);
		button1.setOnClickListener(this);
		button2.setOnClickListener(this);
	}

	
	@Override
	public void onClick(View v) {
		//Selects index of image when button is clicked
		if (v == button1){
			Log.i (DEBUG_LOG, "Clicked button1 or previous button");
			//image index will be decremented on clicking previous image button 
			imageIndex--;
			if(imageIndex<1) imageIndex=5;	//Jumps back to image with index 5
			DrawImage();
		}
		else if (v == button2){

			Log.i (DEBUG_LOG, "Clicked button2 or next button");
			//image index will be incremented on clicking next image button
			imageIndex++;
			if(imageIndex>5) imageIndex=1;	//Jumps back to image with index 1
			DrawImage();
		}
	}
		private void  DrawImage()
		{
			//Select an Image to display based on imageIndex
			//SWITCH statement
			switch(imageIndex){
		    case 0: imageView1.setImageResource(R.drawable.homescreen);	//Displays Home Screen
	               break;
			case 1: imageView1.setImageResource(R.drawable.tiger);		//Displays Tiger
			       break;
			case 2: imageView1.setImageResource(R.drawable.wolf);		//Displays Wolf
		       break;
			case 3: imageView1.setImageResource(R.drawable.elephant);	//Displays Elephant
		       break;
			case 4: imageView1.setImageResource(R.drawable.zirafi);		//Displays zirafi
		       break;
			case 5: imageView1.setImageResource(R.drawable.lion);		//Displays Lion
		       break;
			
		}
			
	}
		@Override
		public void onPause()
		{ 

			Log.i (DEBUG_LOG, "Activity paused");
			super.onPause();
			// save the state of the image
		}
		@Override
		public void onResume()
		{
			super.onResume();

			Log.i (DEBUG_LOG, "Activity resumed");
			//Resumes the state of the image
			DrawImage();
			//Draws image with index before pausing
		}	
}
